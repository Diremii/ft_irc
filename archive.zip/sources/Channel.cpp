/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Channel.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: humontas@student.42.fr <humontas>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/06/03 15:34:40 by ttremel           #+#    #+#             */
/*   Updated: 2026/06/08 12:27:40 by humontas@st      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/Channel.hpp"

Channel::Channel(void) {}

Channel::~Channel(void) {}

Channel::Channel(const std::string &name, User &channelCreator)
{
	this->_name = name;
	this->_users.push_back(channelCreator.getFd());
	this->_operators.push_back(channelCreator.getFd());
	this->_channelCreatorFd = channelCreator.getFd();
	this->_userLimit = (size_t)-1;
	this->_isInviteOnly = false;
	this->_isTopicRestricted = false;
}

Channel::Channel(const Channel &other)
{
	*this = other;
}

Channel &Channel::operator=(const Channel &other)
{
	if (this != &other)
	{
		this->_name = other._name;
		this->_password = other._password;
		this->_topic = other._topic;
		this->_operators = other._operators;
		this->_users = other._users;
		this->_msgs = other._msgs;
		this->_userLimit = other._userLimit;
		this->_isInviteOnly = other._isInviteOnly;
		this->_isTopicRestricted = other._isTopicRestricted;
		this->_channelCreatorFd = other._channelCreatorFd;
	}
	return *this;
}

std::stack<std::string> Channel::getMessages(void)
{
	return _msgs;
}

const std::vector<int> &Channel::getUsers(void) const
{
    return _users;
}

// --------------------
// utils
// --------------------

bool Channel::isUserExist(int clientFd)
{
	for (size_t i = 0; i < _users.size(); i++)
	{
		if (_users[i] == clientFd)
			return true;
	}
	return false;
}

bool Channel::isOperator(int clientFd)
{
	for (size_t i = 0; i < _operators.size(); i++)
	{
		if (_operators[i] == clientFd)
			return true;
	}
	return false;
}

void Channel::removeUser(int clientFd)
{
	for (size_t i = 0; i < _users.size(); i++)
	{
		if (_users[i] == clientFd)
		{
			_users.erase(_users.begin() + i);
			return;
		}
	}
}

// --------------------
// users
// --------------------

void Channel::addUser(int clientFd)
{
	if (_isInviteOnly)
		throw IsInviteOnly();

	if (_users.size() >= _userLimit)
		throw UserLimitReach();

	if (!isUserExist(clientFd))
		_users.push_back(clientFd);
}

void Channel::inviteClient(int clientFd, User &target)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	int targetFd = target.getFd();

	if (!isUserExist(targetFd))
		_users.push_back(targetFd);
}

void Channel::kickClient(int clientFd, int targetFd)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	removeUser(targetFd);
}

// --------------------
// operators
// --------------------

void Channel::giveOperator(int clientFd, int targetFd)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	_operators.push_back(targetFd);
}

void Channel::removeOperator(int clientFd, int targetFd)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	for (size_t i = 0; i < _operators.size(); i++)
	{
		if (_operators[i] == targetFd)
		{
			_operators.erase(_operators.begin() + i);
			return;
		}
	}
}

// --------------------
// settings
// --------------------

std::string Channel::getPassword(int clientFd)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();
	return _password;
}

void Channel::changePassword(int clientFd, const std::string &newPassword)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();
	_password = newPassword;
}

std::string Channel::getName(void)
{
	return _name;
}

std::string Channel::viewTopic(void)
{
	return _topic;
}

void Channel::changeTopic(int clientFd, const std::string &newTopic)
{
	if (_isTopicRestricted && !isOperator(clientFd))
		throw NotAnOperator();
	_topic = newTopic;
}

void Channel::setTopicRestriction(int clientFd, bool isRestricted)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();
	_isTopicRestricted = isRestricted;
}

void Channel::setUserLimit(int clientFd, std::size_t newUserLimit)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	if (newUserLimit < 2)
		throw InvalidLimit();

	_userLimit = newUserLimit;
}

void Channel::removeUserLimit(int clientFd)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	_userLimit = (size_t)-1;
}

void Channel::changeName(int clientFd, const std::string &newName)
{
	if (!isOperator(clientFd))
		throw NotAnOperator();

	_name = newName;
}

void Channel::storeMessages(const std::string &msg)
{
	_msgs.push(msg);
}